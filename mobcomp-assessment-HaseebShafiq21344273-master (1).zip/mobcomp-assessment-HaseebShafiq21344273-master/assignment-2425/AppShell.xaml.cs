﻿using assignment_2425.Services;
using assignment_2425.View;
using System.Windows.Input;

namespace assignment_2425
{
    public partial class AppShell : Shell
    {
        private readonly IAuthService _authService;

        public AppShell()
        {
            InitializeComponent();

            
            _authService = new AuthService();

            
            BindingContext = this;
        }

        
        public ICommand LogoutCommand => new Command(async () => {
            bool confirm = await DisplayAlert("Logout", "Are you sure you want to logout?", "Yes", "No");

            if (confirm)
            {
                _authService.Logout();
                Application.Current.MainPage = new LoginView();
            }
        });

        // command for account menu item
        public ICommand AccountCommand => new Command(async () => {
           
            await Navigation.PushAsync(new profilepage());
        });

        //command for settings
        public ICommand SettingsCommand => new Command(async () => {
            await Navigation.PushAsync(new Settings());
        });

        //command for contact page
        public ICommand ContactCommand => new Command(async () => {
            await Navigation.PushAsync(new ContactUs());
        });

        //command for userdetailpage
        public ICommand DetailCommand => new Command(async () => {
            await Navigation.PushAsync(new UserDetails());
        });
    }
}//comment to publish to github