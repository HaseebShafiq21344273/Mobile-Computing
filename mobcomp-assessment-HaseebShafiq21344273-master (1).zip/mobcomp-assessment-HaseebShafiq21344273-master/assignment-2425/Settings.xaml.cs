using assignment_2425.Services;

namespace assignment_2425;

public partial class Settings : ContentPage
{
    private bool _textToSpeechEnabled = false; // default to false
    private bool _isDarkModeEnabled = false;
    public Settings()
	{
		InitializeComponent();

	}
    private void TxtToSpeechOn_CheckedChanged(object sender, CheckedChangedEventArgs e)
    {
        if (e.Value) //checks if radio button is checked/unchecked
        {
            HapticFeedback.Default.Perform(HapticFeedbackType.Click); //haptic feedback
            _textToSpeechEnabled = true;

            SpeakAsync("Text to speech is now on");
        }
    }

    private void TxtToSpeechOff_CheckedChanged(object sender, CheckedChangedEventArgs e)
    {
        if (e.Value)//checks if radio button is checked/unchecked
        {
            SpeakAsync("Text to speech has been turned off");
            HapticFeedback.Default.Perform(HapticFeedbackType.Click); //haptic feedback
            _textToSpeechEnabled = false;
        }
       
    }

    void OnToggled(object sender, ToggledEventArgs e)
    {
        // provide haptic feedback
        HapticFeedback.Default.Perform(HapticFeedbackType.Click);

        // update dark mode state
        _isDarkModeEnabled = e.Value;

        // apply theme change
        ThemeService.SetTheme(_isDarkModeEnabled);

        // speak theme change if txt to speech is enabled
        if (_textToSpeechEnabled)
        {
            string message = _isDarkModeEnabled ? "Dark mode enabled" : "Light mode enabled";
            SpeakAsync(message);
        }
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();

        _textToSpeechEnabled = Preferences.Default.Get("TextToSpeechEnabled", true); //load settings

        TxtToSpeechOn.IsChecked = _textToSpeechEnabled; //enable txt to speech if checked
        TxtToSpeechOff.IsChecked = !_textToSpeechEnabled; //txt to speech off if off is checked

        _isDarkModeEnabled = ThemeService.IsDarkMode();
        ((Switch)FindByName("ThemeSwitch")).IsToggled = _isDarkModeEnabled;
    }

    protected override void OnDisappearing()
    {
        base.OnDisappearing();

        if (_textToSpeechEnabled)
        {
            Preferences.Default.Set("TextToSpeechEnabled", _textToSpeechEnabled);
        }
        else 
        {
            _textToSpeechEnabled = false;
            Preferences.Default.Set("TextToSpeechEnabled", false);
            
        }
    }

    // txt to speech method
    private async Task SpeakAsync(string text)
    {
        if (_textToSpeechEnabled)
        {
            try
            {
                // create speech options
                var options = new SpeechOptions
                {
                    Volume = 1.0f,
                    Pitch = 1.0f,
                   
                };

                // use TextToSpeech.Default
                await TextToSpeech.Default.SpeakAsync(text, options);
            }
            catch (Exception ex)
            {
                // handle errors 
                Vibration.Default.Vibrate(200); //vibration feature
                Console.WriteLine($"Text-to-speech error: {ex.Message}");
            }
        }
    }
    public static bool IsTextToSpeechEnabled()
    {
        return Preferences.Default.Get("TextToSpeechEnabled", true);
    }

} //comment to publish to github