﻿using Microsoft.Extensions.Logging;
using assignment_2425.Services;
using assignment_2425.View;

namespace assignment_2425
{
    public static class MauiProgram
    {
        public static MauiApp CreateMauiApp()
        {
            var builder = MauiApp.CreateBuilder();
            builder
                .UseMauiApp<App>()
                .ConfigureFonts(fonts =>
                {
                    fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular"); //application fonts
                    fonts.AddFont("OpenSans-Semibold.ttf", "OpenSansSemibold");
                });

            // Register services
            builder.Services.AddSingleton<IAuthService, AuthService>();
            

            // Register pages
            builder.Services.AddTransient<LoginView>();
            builder.Services.AddTransient<MainPage>();
            builder.Services.AddTransient<Meals>();

#if DEBUG
            builder.Logging.AddDebug();
#endif

            return builder.Build();
        }
    }
}//comment to publish to github