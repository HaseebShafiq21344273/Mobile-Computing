using System.Diagnostics;
using assignment_2425.Services;

namespace assignment_2425.View
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class LoginView : ContentPage
    {
        private readonly IAuthService _authService;

        public LoginView()
        {
            InitializeComponent();
            _authService = new AuthService();

            
            if (_authService.IsUserLoggedIn())
            {
                // navigate to main page if already logged in
                Application.Current.MainPage = new AppShell();
            }
        }

        private async void OnLoginClicked(object sender, EventArgs e)
        {
            // get email and password 
            
            try
            {
                // get the email and password values 
                string email = string.Empty;
                string password = string.Empty;

                
                var emailEntry = FindByName("EmailEntry") as Entry;
                if (emailEntry != null)
                {
                    email = emailEntry.Text?.Trim() ?? string.Empty;
                }

                
                var passwordEntry = FindByName("PasswordEntry") as Entry;
                if (passwordEntry != null)
                {
                    password = passwordEntry.Text ?? string.Empty;
                }

                // validate inputs
                if (string.IsNullOrEmpty(email))
                {
                    await DisplayAlert("Login Failed", "Please enter your email address", "OK");
                    Vibration.Default.Vibrate(200); //vibration feature
                    return;
                }

                if (string.IsNullOrEmpty(password))
                {
                    await DisplayAlert("Login Failed", "Please enter your password", "OK");
                    Vibration.Default.Vibrate(200); //vibration feature
                    return;
                }

                
                if (_authService.ValidateCredentials(email, password))
                {
                    // save the user session
                    _authService.SaveUserSession(email);

                    // set the main page as the current page
                    Application.Current.MainPage = new AppShell();
                }
                else
                {
                    await DisplayAlert("Login Failed", "Invalid email or password", "OK");
                    Vibration.Default.Vibrate(200); //vibration feature
                }
            }
            catch (Exception ex)
            {
                // log the error
                Vibration.Default.Vibrate(200); //vibration feature
                Debug.WriteLine($"Login error: {ex.Message}");
                await DisplayAlert("Error", "An error occurred during login. Please try again.", "OK");
            }
        }

        private async void OnRegisterClicked(object sender, EventArgs e)
        {

            
            await DisplayAlert("Register", "Registration functionality would be implemented here in my complete app", "OK");
        }

        private async void OnGuestLoginTapped(object sender, EventArgs e)
        {
           
            Preferences.Set("IsGuestUser", true);

            Application.Current.MainPage = new AppShell();
        }
    }
} //comment to publish to github