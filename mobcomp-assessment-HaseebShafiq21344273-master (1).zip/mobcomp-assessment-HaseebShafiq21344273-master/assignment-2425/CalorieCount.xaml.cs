namespace assignment_2425;

public partial class CalorieCount : ContentPage
{
	public CalorieCount()
	{
		InitializeComponent();
	}
}