﻿using assignment_2425.Services;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Input;

namespace assignment_2425.View
{
    class MealsViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged; //event for notifying user

        private readonly INutritionixApiService _nutritionService; //api service

        private ObservableCollection<FoodItem> _searchResults = new ObservableCollection<FoodItem>(); //collection storing search results
        public ObservableCollection<FoodItem> SearchResults { get => _searchResults; }

        private ObservableCollection<FoodDiaryEntry> _foodDiary = new ObservableCollection<FoodDiaryEntry>(); //collections to store food diary entry
        public ObservableCollection<FoodDiaryEntry> FoodDiary { get => _foodDiary; }

        private ObservableCollection<Grouping<string, FoodDiaryEntry>> _groupedFoodDiary = //collection to store food diary thats grouped via meal type
            new ObservableCollection<Grouping<string, FoodDiaryEntry>>();
        public ObservableCollection<Grouping<string, FoodDiaryEntry>> GroupedFoodDiary { get => _groupedFoodDiary; }

        

        private string _searchQuery; //track search query
        public string SearchQuery
        {
            get => _searchQuery;
            set
            {
                if (_searchQuery != value)
                {
                    _searchQuery = value;
                    OnPropertyChanged(); //notify ui
                }
            }
        }

        private FoodItem _selectedFood; //track current selected food
        public FoodItem SelectedFood
        {
            get => _selectedFood;
            set
            {
                if (_selectedFood != value)
                {
                    _selectedFood = value;
                    OnPropertyChanged();
                    if (_selectedFood != null)
                    {
                        GetNutritionInfo(_selectedFood); //when selected get detailed nutritional information
                    }
                }
            }
        }

        private string _selectedFoodName; //tarck name of selected food
        public string SelectedFoodName
        {
            get => _selectedFoodName;
            set
            {
                if (_selectedFoodName != value)
                {
                    _selectedFoodName = value;
                    OnPropertyChanged();
                }
            }
        }

        private string _selectedFoodCalories;  // food cal
        public string SelectedFoodCalories
        {
            get => _selectedFoodCalories;
            set
            {
                if (_selectedFoodCalories != value)
                {
                    _selectedFoodCalories = value;
                    OnPropertyChanged();
                }
            }
        }

        private string _selectedFoodProtein; //protien
        public string SelectedFoodProtein
        {
            get => _selectedFoodProtein;
            set
            {
                if (_selectedFoodProtein != value)
                {
                    _selectedFoodProtein = value;
                    OnPropertyChanged();
                }
            }
        }

        private string _selectedFoodCarbs; //carbs
        public string SelectedFoodCarbs
        {
            get => _selectedFoodCarbs;
            set
            {
                if (_selectedFoodCarbs != value)
                {
                    _selectedFoodCarbs = value;
                    OnPropertyChanged();
                }
            }
        }

        private string _selectedFoodFat; //fat
        public string SelectedFoodFat
        {
            get => _selectedFoodFat;
            set
            {
                if (_selectedFoodFat != value)
                {
                    _selectedFoodFat = value;
                    OnPropertyChanged();
                }
            }
        }

        private bool _isLoading; //loading indicator to know wen data is being loaded from api
        public bool IsLoading
        {
            get => _isLoading;
            set
            {
                if (_isLoading != value)
                {
                    _isLoading = value;
                    OnPropertyChanged();
                }
            }
        }

        private bool _isSelectedFoodVisible; //see if the selected food info is visable
        public bool IsSelectedFoodVisible
        {
            get => _isSelectedFoodVisible;
            set
            {
                if (_isSelectedFoodVisible != value)
                {
                    _isSelectedFoodVisible = value;
                    OnPropertyChanged();
                }
            }
        }

        private bool _areSearchResultsVisible; //see if search results can be seen
        public bool AreSearchResultsVisible
        {
            get => _areSearchResultsVisible;
            set
            {
                if (_areSearchResultsVisible != value)
                {
                    _areSearchResultsVisible = value;
                    OnPropertyChanged();
                }
            }
        }

        private string _totalCalories = "0 calories"; //property to show data
        public string TotalCalories
        {
            get => _totalCalories;
            set
            {
                if (_totalCalories != value)
                {
                    _totalCalories = value;
                    OnPropertyChanged();
                }
            }
        }

        private string _macroBreakdown = "0g protein | 0g carbs | 0g fat"; //show macros
        public string MacroBreakdown
        {
            get => _macroBreakdown;
            set
            {
                if (_macroBreakdown != value)
                {
                    _macroBreakdown = value;
                    OnPropertyChanged();
                }
            }
        }

        private ServingSize _selectedServingSize; //current selected serving size
        public ServingSize SelectedServingSize
        {
            get => _selectedServingSize;
            set
            {
                if (_selectedServingSize != value)
                {
                    _selectedServingSize = value;
                    OnPropertyChanged();
                    UpdateNutritionBasedOnServingAndQuantity(); //update infor based on serving size
                }
            }
        }
        private ObservableCollection<ServingSize> _servingSizes = new ObservableCollection<ServingSize>(); //collection of serving sizes to chose from 
        public ObservableCollection<ServingSize> ServingSizes
        {
            get => _servingSizes;
            set
            {
                if (_servingSizes != value)
                {
                    _servingSizes = value;
                    OnPropertyChanged();
                }
            }
        }

        private double _quantity = 1; //quantity level of food
        public double Quantity
        {
            get => _quantity;
            set
            {
                if (_quantity != value)
                {
                    _quantity = value;
                    OnPropertyChanged();
                    QuantityText = value.ToString("0.#"); //update text
                    UpdateNutritionBasedOnServingAndQuantity(); //update based on quantity
                }
            }
        }

        private string _quantityText = "1"; //text update for quantity
        public string QuantityText
        {
            get => _quantityText;
            set
            {
                if (_quantityText != value)
                {
                    _quantityText = value;
                    OnPropertyChanged();
                }
            }
        }

        private string _selectedMealType; //meal type property
        public string SelectedMealType
        {
            get => _selectedMealType;
            set
            {
                if (_selectedMealType != value)
                {
                    _selectedMealType = value;
                    OnPropertyChanged();
                }
            }
        }

        public ICommand SearchCommand { get; } //command for food search
        public ICommand AddToDiaryCommand { get; } //command for adding to diary
        public ICommand DeleteFoodCommand { get; } //command for delting food
        public ICommand ReadPageContentCommand { get; } //command for txt to speech

        public MealsViewModel(INutritionixApiService nutritionixService)   //using api service
        {
            _nutritionService = nutritionixService;

            SearchCommand = new Command(async () => await SearchFood()); //commands and handler 
            AddToDiaryCommand = new Command(AddToDiary);
            DeleteFoodCommand = new Command<FoodDiaryEntry>(RemoveFoodFromDiary);
            ReadPageContentCommand = new Command(ReadPageContent);

            LoadFoodDiary(); //load diary on app start
        }

        protected void OnPropertyChanged([CallerMemberName] string propertyName = null) //helper method notifying ui
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        private async Task SearchFood() //search uing nutritionix api
        {
            if (string.IsNullOrEmpty(SearchQuery)) //if search query is valid
            {
                await Application.Current.MainPage.DisplayAlert("Error", "Please enter a food to search for", "OK");
                Vibration.Default.Vibrate(200); //vibrate function
                return;
            }

            try
            {
                IsLoading = true; //loading indicator will be visable
                SearchResults.Clear(); //clear past seach results

                var searchResponse = await _nutritionService.SearchFoods(SearchQuery); //calling api to search food

                // Process common foods
                if (searchResponse.Common != null)  //process for common food types
                {
                    foreach (var item in searchResponse.Common)
                    {
                        var foodItem = new FoodItem
                        {
                            Name = item.FoodName,
                            Description = "Common Food",
                            FoodId = item.FoodName
                        };

                        SearchResults.Add(foodItem); //add food item to search results
                    }
                }

                // Process branded foods
                if (searchResponse.Branded != null)
                {
                    foreach (var item in searchResponse.Branded) //process for branded items
                    {
                        var foodItem = new FoodItem
                        {
                            Name = item.FoodName,
                            Description = item.BrandName,
                            FoodId = item.NixItemId,
                            BrandName = item.BrandName
                        };

                        SearchResults.Add(foodItem);
                    }
                }

                AreSearchResultsVisible = true; //update ui to show results
            }
            catch (Exception ex)
            {
                await Application.Current.MainPage.DisplayAlert("Error", $"An error occurred: {ex.Message}", "OK"); //error handling
                Vibration.Default.Vibrate(200); //vibrate function
            }
            finally
            {
                IsLoading = false; //hide the loading indicator
            }
        }

        private async Task GetNutritionInfo(FoodItem foodItem) //method to get nutritional info for food item
        {
            try
            {
                IsLoading = true; //inicator shown

                string nixItemId = null; //check in place to see item is branded
                if (!string.IsNullOrEmpty(foodItem.FoodId) && foodItem.FoodId != foodItem.Name)
                {
                    nixItemId = foodItem.FoodId;
                }

                Console.WriteLine($"Getting nutrition for: {foodItem.Name}, ID: {foodItem.FoodId}"); //output for user

                try
                {
                    var nutritionResponse = await _nutritionService.GetNutrientInfo(foodItem.Name, nixItemId); //call api to get nutritional info

                    if (nutritionResponse?.Foods != null && nutritionResponse.Foods.Count > 0)
                    {
                        var food = nutritionResponse.Foods[0];

                        foodItem.CaloriesPerServing = food.NfCalories;
                        foodItem.ProteinPerServing = food.NfProtein;
                        foodItem.CarbsPerServing = food.NfTotalCarbohydrate;            //storing info for food item
                        foodItem.FatPerServing = food.NfTotalFat;

                        foodItem.ServingSizes.Clear();

                        foodItem.ServingSizes.Add(new ServingSize           //add defualt serving size by defualt
                        {
                            Description = $"{food.ServingQty} {food.ServingUnit}",
                            Quantity = food.ServingQty,
                            Unit = food.ServingUnit,
                            Weight = food.ServingWeightGrams
                        });

                        if (food.AltMeasures != null) //if other serving size available
                        {
                            foreach (var measure in food.AltMeasures)
                            {
                                if (measure.Measure == food.ServingUnit && //if serve size is same then skip
                                    Math.Abs(measure.Qty - food.ServingQty) < 0.01)
                                    continue;

                                foodItem.ServingSizes.Add(new ServingSize //add new serbing size to display
                                {
                                    Description = $"{measure.Qty} {measure.Measure}",
                                    Quantity = measure.Qty,
                                    Unit = measure.Measure,
                                    Weight = measure.ServingWeight
                                });
                            }
                        }

                        _selectedFood = foodItem;
                        DisplayFoodDetails(foodItem); //update the ui
                    }
                    else
                    {
                        Vibration.Default.Vibrate(200); //vibration feature
                        await Application.Current.MainPage.DisplayAlert("Notice", "Couldn't get detailed nutrition information for this food.", "OK"); //error handling w/ vibration
                    }
                }
                catch (Exception ex)
                {
                    Vibration.Default.Vibrate(200); //vibration feature
                    await Application.Current.MainPage.DisplayAlert("API Error", $"Couldn't get nutrition data: {ex.Message}", "OK");
                }
            }
            catch (Exception ex)
            {
                Vibration.Default.Vibrate(200); //vibration feature
                await Application.Current.MainPage.DisplayAlert("Error", $"An error occurred: {ex.Message}", "OK");
            }
            finally
            {
                IsLoading = false;
            }
        }

        private void DisplayFoodDetails(FoodItem foodItem) //update ui with selected food details
        {
            SelectedFoodName = foodItem.Name;
            SelectedFoodCalories = $"{foodItem.CaloriesPerServing} cal"; //food properties
            SelectedFoodProtein = $"{foodItem.ProteinPerServing}g";
            SelectedFoodCarbs = $"{foodItem.CarbsPerServing}g";
            SelectedFoodFat = $"{foodItem.FatPerServing}g";

            ServingSizes.Clear(); //clear for repopulation
            foreach (var size in foodItem.ServingSizes)
            {
                ServingSizes.Add(size);
            }


            if (foodItem.ServingSizes.Count > 0)  //first serving size is defualt
                SelectedServingSize = foodItem.ServingSizes[0];

            Quantity = 1; //reset for quantity
            QuantityText = "1";

            IsSelectedFoodVisible = true; //ui update
        }

        private void UpdateNutritionBasedOnServingAndQuantity() //update method for info
        {
            if (_selectedFood == null || SelectedServingSize == null)
                return;

            var baseServingSize = _selectedFood.ServingSizes[0]; //base serving size
            var servingRatio = SelectedServingSize.Weight / baseServingSize.Weight;     //selected agaisnt base calculation

            var calories = _selectedFood.CaloriesPerServing * servingRatio * Quantity;  //calculations based on quantity and serving sizes
            var protein = _selectedFood.ProteinPerServing * servingRatio * Quantity;
            var carbs = _selectedFood.CarbsPerServing * servingRatio * Quantity;
            var fat = _selectedFood.FatPerServing * servingRatio * Quantity;

            SelectedFoodCalories = $"{calories:0.#} cal";  //update for ui
            SelectedFoodProtein = $"{protein:0.#}g";
            SelectedFoodCarbs = $"{carbs:0.#}g";
            SelectedFoodFat = $"{fat:0.#}g";
        }

        private void AddToDiary()
        {
            try
            {
                if (_selectedFood == null)
                {
                    Application.Current.MainPage.DisplayAlert("Error", "No food selected", "OK"); //error handling with vibration function 
                    Vibration.Default.Vibrate(200);
                    return;
                }

                if (string.IsNullOrEmpty(SelectedMealType))         //error handling for meal tyoe selection
                {
                    Application.Current.MainPage.DisplayAlert("Error", "Please select a meal type", "OK");
                    Vibration.Default.Vibrate(200);
                    return;
                }

                if (SelectedServingSize == null)  //serving size error handling 
                {
                    Application.Current.MainPage.DisplayAlert("Error", "Please select a serving size", "OK");
                    Vibration.Default.Vibrate(200);
                    return;
                }

                Console.WriteLine($"Adding to diary: {_selectedFood.Name}, Meal: {SelectedMealType}, Quantity: {Quantity}"); //notify user that item is being added to diary

                var baseServingSize = _selectedFood.ServingSizes[0];
                var servingRatio = SelectedServingSize.Weight / baseServingSize.Weight;

                var calories = _selectedFood.CaloriesPerServing * servingRatio * Quantity;
                var protein = _selectedFood.ProteinPerServing * servingRatio * Quantity;
                var carbs = _selectedFood.CarbsPerServing * servingRatio * Quantity;
                var fat = _selectedFood.FatPerServing * servingRatio * Quantity;

                var entry = new FoodDiaryEntry
                {
                    FoodId = _selectedFood.FoodId,
                    FoodName = _selectedFood.Name,
                    MealType = SelectedMealType,
                    ServingInfo = $"{Quantity} × {SelectedServingSize.Description}",
                    Quantity = Quantity,
                    ServingSizeUnit = SelectedServingSize.Unit,
                    Calories = calories,                                            //new food diary entry
                    Protein = protein,
                    Carbs = carbs,
                    Fat = fat,
                    Date = DateTime.Today
                };

                _foodDiary.Add(entry); //add to food diary
                Console.WriteLine($"Added entry to food diary. Total entries: {_foodDiary.Count}"); //notify user

                SaveFoodDiary(); //save dairy entries
                UpdateGroupedFoodDiary(); //update food diary based on entries
                UpdateDailyTotals(); //update daily total for main page ussage

                IsSelectedFoodVisible = false; //hide food details
                SelectedMealType = null; //reset section

                Application.Current.MainPage.DisplayAlert("Success", $"{_selectedFood.Name} added to your {SelectedMealType} diary", "OK"); //notify user when item has been added
                Vibration.Default.Vibrate(200); //vibrate function
            }
            catch (Exception ex)
            {
                Application.Current.MainPage.DisplayAlert("Error", $"Failed to add food to diary: {ex.Message}", "OK");     //error handling 
                Vibration.Default.Vibrate(200);
                Console.WriteLine($"Error in AddToDiary: {ex.Message}\n{ex.StackTrace}");
            }
        }

        private void UpdateGroupedFoodDiary() //method for updating grouped food diary based on meal typre
        {
            try
            {
                _groupedFoodDiary.Clear(); //clear any data there

                Console.WriteLine($"Updating grouped food diary. Total items: {_foodDiary.Count}");
                foreach (var item in _foodDiary)
                {
                    Console.WriteLine($"  Item: {item.FoodName}, Meal: {item.MealType}, Date: {item.Date.ToShortDateString()}"); 
                }

                var todayEntries = _foodDiary
                    .Where(entry => entry.Date.Date == DateTime.Today.Date) //filter for items added to day - doesnt work properly
                    .ToList();

                Console.WriteLine($"Today's entries: {todayEntries.Count}");

                var mealTypes = new[] { "Breakfast", "Lunch", "Dinner", "Snack" };  //my meal types

                foreach (var mealType in mealTypes)
                {
                    var entriesForMeal = todayEntries   //creating group for each meal type
                        .Where(e => e.MealType == mealType)
                        .ToList();

                    Console.WriteLine($"Meal type {mealType} has {entriesForMeal.Count} entries");

                    _groupedFoodDiary.Add(new Grouping<string, FoodDiaryEntry>(mealType, entriesForMeal));
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in UpdateGroupedFoodDiary: {ex.Message}\n{ex.StackTrace}"); //error handling
                Vibration.Default.Vibrate(200); //vibrate function
            }
        }

        private void RemoveFoodFromDiary(FoodDiaryEntry entry) //remove method
        {
            if (entry == null)
                return;

            Console.WriteLine($"Removing food from diary: {entry.FoodName}"); 

            _foodDiary.Remove(entry); //remove from diary
            UpdateGroupedFoodDiary(); //update 
            SaveFoodDiary();
            UpdateDailyTotals();//change daily totals after item is removed

            Application.Current.MainPage.DisplayAlert("Deleted", $"{entry.FoodName} has been removed from your diary", "OK"); //notify user
            Vibration.Default.Vibrate(200);
        }

        private async void ReadPageContent() //txt to speech method
        {
            string pageContent = "Meals page. ";

            if (GroupedFoodDiary.Count > 0)
            {
                pageContent += "Today's Food Diary. ";
                pageContent += $"{TotalCalories}. {MacroBreakdown}. ";
            }
            else
            {
                pageContent += "No meals added today. Search for food to add.";
            }

            if (IsSelectedFoodVisible)
            {
                pageContent += $"Selected food: {SelectedFoodName}. " +  //content to read
                               $"Calories: {SelectedFoodCalories}. " +
                               $"Protein: {SelectedFoodProtein}. " +
                               $"Carbs: {SelectedFoodCarbs}. " +
                               $"Fat: {SelectedFoodFat}.";
            }

            await TextToSpeechVoice.SpeakTextAsync(pageContent);
        }

        private void UpdateDailyTotals() //method for mainapge to pass macro info
        {
            var todayEntries = _foodDiary.Where(entry => entry.Date.Date == DateTime.Today.Date);

            var totalCalories = todayEntries.Sum(entry => entry.Calories);
            var totalProtein = todayEntries.Sum(entry => entry.Protein);
            var totalCarbs = todayEntries.Sum(entry => entry.Carbs);
            var totalFat = todayEntries.Sum(entry => entry.Fat);

            TotalCalories = $"{totalCalories:0} calories";
            MacroBreakdown = $"{totalProtein:0}g protein | {totalCarbs:0}g carbs | {totalFat:0}g fat";
        }

        private void SaveFoodDiary() //save to preferences for temp storage
        {
            try
            {
                var json = JsonSerializer.Serialize(_foodDiary);
                Preferences.Set("FoodDiary", json);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error saving food diary: {ex.Message}");
            }
        }

        private void LoadFoodDiary() // load from food diary
        {
            try
            {
                var json = Preferences.Get("FoodDiary", string.Empty);
                if (!string.IsNullOrEmpty(json))
                {
                    var entries = JsonSerializer.Deserialize<ObservableCollection<FoodDiaryEntry>>(json);
                    if (entries != null)
                    {
                        foreach (var entry in entries)
                        {
                            _foodDiary.Add(entry);
                        }
                        UpdateGroupedFoodDiary();
                        UpdateDailyTotals();
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error loading food diary: {ex.Message}"); //error handling
                Vibration.Default.Vibrate(200); //vibrate function
            }
        }
    }
} //comment to publish to github