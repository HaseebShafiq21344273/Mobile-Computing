﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace assignment_2425.Services
{
    public interface INutritionixApiService
    {
        Task<NutritionixSearchResponse> SearchFoods(string query);
        Task<NutritionixNutrientsResponse> GetNutrientInfo(string query, string nixItemId = null);
    }

    public class NutritionixApiService : INutritionixApiService
    {
        private readonly HttpClient _client;
        private readonly string _baseUrl = "https://trackapi.nutritionix.com/v2";
        private readonly JsonSerializerOptions _jsonOptions;

        public NutritionixApiService()
        {
            _client = new HttpClient();

            // get API credentials from App
            string apiId = App.NutritionixApiId;
            string apiKey = App.NutritionixApiKey;

            // add headers
            _client.DefaultRequestHeaders.Add("x-app-id", apiId);
            _client.DefaultRequestHeaders.Add("x-app-key", apiKey);
            _client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            // json options with property name policy
            _jsonOptions = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            };
        }

        public async Task<NutritionixSearchResponse> SearchFoods(string query) //food search method
        {
            // create request body
            var requestBody = new
            {
                query = query,
                detailed = true,
                common = true,
                branded = true
            };

            var json = JsonSerializer.Serialize(requestBody); 
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            // make the API call
            var response = await _client.PostAsync($"{_baseUrl}/search/instant", content);

            if (response.IsSuccessStatusCode)
            {
                var responseContent = await response.Content.ReadAsStringAsync();
                                                                                        // log the response for debugging
                Console.WriteLine($"API Response: {responseContent}");
                return JsonSerializer.Deserialize<NutritionixSearchResponse>(responseContent, _jsonOptions);
            }

            throw new Exception($"Failed to search foods. Status code: {response.StatusCode}");

        }

        public async Task<NutritionixNutrientsResponse> GetNutrientInfo(string query, string nixItemId = null) //method fo rnutritional info
        {
            try
            {
                // request body
                object requestBody;

                if (!string.IsNullOrEmpty(nixItemId) && nixItemId != query)
                {
                    // for branded items with nix_item_id
                    requestBody = new
                    {
                        nix_item_id = nixItemId
                    };
                }
                else
                {
                    // for common foods or when nix_item_id not available
                    requestBody = new
                    {
                        query = query
                    };
                }

                var json = JsonSerializer.Serialize(requestBody);
                Console.WriteLine($"Nutrient request: {json}");
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                // make the API call
                var response = await _client.PostAsync($"{_baseUrl}/natural/nutrients", content);
                var responseContent = await response.Content.ReadAsStringAsync();

                Console.WriteLine($"Nutrient API response code: {response.StatusCode}");
                Console.WriteLine($"Nutrient API response: {responseContent}");

                if (response.IsSuccessStatusCode)
                {
                    return JsonSerializer.Deserialize<NutritionixNutrientsResponse>(responseContent, _jsonOptions); //deseriealise
                }

                throw new Exception($"Failed to get nutrition info. Status code: {response.StatusCode}. Response: {responseContent}"); //error for api failure
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception in GetNutrientInfo: {ex.Message}"); 
                throw;
            }
        }
    }

    // API response classes
    public class NutritionixSearchResponse //produces responce for food search
    {
        public List<NutritionixCommonFood> Common { get; set; }
        public List<NutritionixBrandedFood> Branded { get; set; }
    }

    public class NutritionixCommonFood //class for common food item
    {
        [JsonPropertyName("food_name")]
        public string FoodName { get; set; }

        [JsonPropertyName("serving_unit")]
        public string ServingUnit { get; set; }

        [JsonPropertyName("serving_qty")]
        public double ServingQty { get; set; }

        public NutritionixPhoto Photo { get; set; }
    }

    public class NutritionixPhoto //does not work tried to implement but failed/ maybe in future
    {
        public string Thumb { get; set; }
    }

    public class NutritionixBrandedFood //class for branded items
    {
        [JsonPropertyName("food_name")]
        public string FoodName { get; set; }

        [JsonPropertyName("brand_name")]
        public string BrandName { get; set; }

        [JsonPropertyName("serving_unit")]
        public string ServingUnit { get; set; }

        [JsonPropertyName("serving_qty")]
        public double ServingQty { get; set; }

        [JsonPropertyName("nix_item_id")]
        public string NixItemId { get; set; }

        public NutritionixPhoto Photo { get; set; } //useless
    }

    public class NutritionixNutrientsResponse //calss for nutrient info 
    {
        [JsonPropertyName("foods")]
        public List<NutritionixFood> Foods { get; set; } //creats list of food with info
    }

    public class NutritionixFood //detailed food indo
    {
        [JsonPropertyName("food_name")]
        public string FoodName { get; set; }

        [JsonPropertyName("brand_name")]
        public string BrandName { get; set; }

        [JsonPropertyName("serving_qty")]
        public double ServingQty { get; set; }

        [JsonPropertyName("serving_unit")]
        public string ServingUnit { get; set; }

        [JsonPropertyName("serving_weight_grams")]
        public double ServingWeightGrams { get; set; }

        [JsonPropertyName("nf_calories")]
        public double NfCalories { get; set; }

        [JsonPropertyName("nf_total_fat")]
        public double NfTotalFat { get; set; }

        [JsonPropertyName("nf_saturated_fat")]
        public double NfSaturatedFat { get; set; }

        [JsonPropertyName("nf_cholesterol")]
        public double NfCholesterol { get; set; }

        [JsonPropertyName("nf_sodium")]
        public double NfSodium { get; set; }

        [JsonPropertyName("nf_total_carbohydrate")]
        public double NfTotalCarbohydrate { get; set; }

        [JsonPropertyName("nf_dietary_fiber")]
        public double NfDietaryFiber { get; set; }

        [JsonPropertyName("nf_sugars")]
        public double NfSugars { get; set; }

        [JsonPropertyName("nf_protein")]
        public double NfProtein { get; set; }

        [JsonPropertyName("alt_measures")]
        public List<NutritionixAltMeasure> AltMeasures { get; set; }
    }

    public class NutritionixAltMeasure //alt serving measurments options
    {
        public string Measure { get; set; }
        public double Qty { get; set; }

        [JsonPropertyName("serving_weight")]
        public double ServingWeight { get; set; }
    }
} //comment to publish to github