namespace assignment_2425;

public partial class stats : ContentPage
{
	public stats()
	{
		InitializeComponent();
	}
}