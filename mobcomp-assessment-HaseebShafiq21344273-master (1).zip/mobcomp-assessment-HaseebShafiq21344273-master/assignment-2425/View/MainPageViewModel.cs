﻿using assignment_2425.Services; // use services
using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Text.Json;
using System.Windows.Input;
using assignment_2425.View;

namespace assignment_2425.ViewModels
{
    public class MainPageViewModel : INotifyPropertyChanged //let the ui know when it has chnaged
    {
        public event PropertyChangedEventHandler PropertyChanged; //event for notification when values chnage

        private string _totalCaloriesLabel = "0 calories"; 
        private string _macroBreakdown = "0g protein | 0g carbs | 0g fat";
        private string _totalCalsNeeded = "0 Cals"; //all data values for mainpage stored here
        private readonly IAuthService _authService; // auth service for handling login page


        public string TotalCalories
        {
            get => _totalCaloriesLabel; //get the values for calories 
            set
            {
                if (_totalCaloriesLabel != value) //if value is updated then change
                {
                    _totalCaloriesLabel = value;//store new value
                    OnPropertyChanged();//notify ui that there is a change
                }
            }
        }

        public string TotalCalsNeeded //get current value
        {
            get => _totalCalsNeeded; 
            set
            {
                if (_totalCalsNeeded != value)
                {
                    _totalCalsNeeded = value;
                    OnPropertyChanged();
                }
            }
        }

        public string MacroBreakdownLabel
        {
            get => _macroBreakdown;
            set
            {
                if (_macroBreakdown != value)
                {
                    _macroBreakdown = value;
                    OnPropertyChanged();
                }
            }
        }

        public ICommand ReadMainContentCommand { get; } //txt to speech command for button
        public ICommand NavigateToMealsCommand { get; }// go to meals page command
        public ICommand NavigateToSettingsCommand { get; } // go to settings page
        public ICommand LogoutCommand { get; }// logging out command

        public MainPageViewModel(IAuthService authService) 
        {
            _authService = authService; //auth service store

            ReadMainContentCommand = new Command(OnReadMainContent); //connecting commands to handler
            NavigateToMealsCommand = new Command(OnNavigateToMeals);
            NavigateToSettingsCommand = new Command(OnNavigateToSettings);
            LogoutCommand = new Command(OnLogout);

            LoadFoodDiaryData(); //load data
            LoadRecommendedCalories();
        }

        // onproperty method, tells ui when a property change has occured to update 
        protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public void LoadFoodDiaryData() //loading stored food dairy data
        {
            try
            {
                // load the food diary data from preferences
                var json = Preferences.Get("FoodDiary", string.Empty);
                if (string.IsNullOrEmpty(json))
                {
                    // with no data yet
                    TotalCalories = "0 calories";
                    MacroBreakdownLabel = "0g protein | 0g carbs | 0g fat"; //default values
                    return;
                }

                // deserialize the food diary entries into list
                var foodDiary = JsonSerializer.Deserialize<List<FoodDiaryEntry>>(json);
                if (foodDiary == null)
                {                                                       //if desearealize fails then output defualt values
                    TotalCalories = "0 calories";
                    MacroBreakdownLabel = "0g protein | 0g carbs | 0g fat";
                    return;
                }

                // calculate totals
                double totalCalories = foodDiary.Sum(e => e.Calories);
                double totalProtein = foodDiary.Sum(e => e.Protein);
                double totalCarbs = foodDiary.Sum(e => e.Carbs);
                double totalFat = foodDiary.Sum(e => e.Fat);

                // update totalCalories  MacroBreakdownLabel
                TotalCalories = $"{totalCalories:F0} calories";
                MacroBreakdownLabel = $"{totalProtein:F0}g protein | {totalCarbs:F0}g carbs | {totalFat:F0}g fat";
            }
            catch (Exception ex)
            {
                Vibration.Default.Vibrate(200); //vibration feature
                Console.WriteLine($"Error loading food diary data: {ex.Message}"); //error message 
                TotalCalories = "Could not load data";
                MacroBreakdownLabel = "Error loading nutrition data";
            }
        }

        public void LoadRecommendedCalories() //load calorie intake from storage
        {
            int recommendedCalories = Preferences.Get("RecommendedCalories", 0);

            if (recommendedCalories > 0)
            {
                TotalCalsNeeded = $"{recommendedCalories} Cals"; //if there is a value then show
            }
            else
            {
                TotalCalsNeeded = "Not Yet Calculated"; //if not
            }
        }

        private async void OnReadMainContent() //when txt to speech button is pressed
        {
            // collect content from my page as string
            string MainContent = "Main page. ";

            // add any available info from buttons
            MainContent += $": Calorie Tracker!. " +
                           $": Smart tracking for a healthier you. " +
                           $": Daily Totals. " +
                           $"Calories: {TotalCalories}. " +
                           $"Daily Macro Intake: {MacroBreakdownLabel}." +
                           $": Calorie Intake Needed" +
                           $": {TotalCalsNeeded}";

            await TextToSpeechVoice.SpeakTextAsync(MainContent); //using txt to speech service to read content
        }

        private async void OnNavigateToMeals() //navigate to meals page
        {
            Application.Current.MainPage = new Meals();
        }

        private async void OnNavigateToSettings() //navigate to settings if button pressed
        {
            await Shell.Current.Navigation.PushAsync(new Settings());
        }

        private async void OnLogout()
        {
            bool confirm = await Application.Current.MainPage.DisplayAlert( 
                "Logout", "Are you sure you want to logout?", "Yes", "No"); //asking user for confirmation to logout

            if (confirm)
            {
                _authService.Logout();
                Application.Current.MainPage = new LoginView(); //if logged out go to login page
            }
        }
    }
} //comment to publish to github