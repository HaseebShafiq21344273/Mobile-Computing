using assignment_2425.Services;
using static Microsoft.Maui.ApplicationModel.Permissions;
namespace assignment_2425;

public partial class ContactUs : ContentPage
{
	public ContactUs()
	{
		InitializeComponent();
	}

    private async void ReadContactContent_Clicked(object sender, EventArgs e) //handler for txt to speech
    {
        // collect content from my page
        string ContactContent = "Contact page. ";
        // add any available info from buttons
        ContactContent += $": {ContactHeading.Text}. " +
                           $": {ConatactMessage.Text}. " +
                           $": {SendMessageLabel.Text}. " +
                           $"Calories: {NameEntry.Text}. " +
                           $"Daily Macro Intake: {EmailEntry.Text}." +
                           $": {MessageEditor.Text}." +
                           $":   {SendMessage.Text}." +
                           $"{EmailContact.Text}." +
                           $"{PhoneNo.Text}." +
                           $"{LocationContact.Text}." +
                           $"{BuisnessHours.Text}";
        await TextToSpeechVoice.SpeakTextAsync(ContactContent);
    }

    private void OnSendMessageClicked(object sender, EventArgs e)
    {
        HapticFeedback.Default.Perform(HapticFeedbackType.Click);
    }
}//comment to publish to github