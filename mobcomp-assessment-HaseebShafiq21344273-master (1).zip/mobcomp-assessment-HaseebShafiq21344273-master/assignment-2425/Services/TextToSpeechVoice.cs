﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment_2425.Services
{
    public static class TextToSpeechVoice
    {
        public static async Task SpeakTextAsync(string text, float? volume = null, float? pitch = null, float? rate = null)
        {
            // chwck if txttospeech is enabled
            if (Settings.IsTextToSpeechEnabled())
            {
                try
                {

                    // create speech settings
                    var options = new SpeechOptions
                    {
                        Volume = volume ?? 1.0f,
                        Pitch = pitch ?? 1.0f,
                        
                    };

                    
                    await TextToSpeech.Default.SpeakAsync(text, options);
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Text-to-speech error: {ex.Message}");
                }
            }
        }

        
    }
}//comment to publish to github
