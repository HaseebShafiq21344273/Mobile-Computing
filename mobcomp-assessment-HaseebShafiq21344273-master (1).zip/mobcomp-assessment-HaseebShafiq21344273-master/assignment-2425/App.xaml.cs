﻿using assignment_2425.Services;
using assignment_2425.View;
using System.Windows.Input;

namespace assignment_2425
{
    public partial class App : Application
    {
        private readonly IAuthService _authService;
        public ICommand LogoutCommand { get; }

        // add properties for Nutritionix API
        public static string NutritionixApiId { get; private set; }
        public static string NutritionixApiKey { get; private set; }

        public App()
        {
            InitializeComponent();

            // setting Nutritionix API credentials
            NutritionixApiId = "6502b56b";  // API ID
            NutritionixApiKey = "49d8271c3e6ee89105c26912437c61b3"; // API Key

            // Initialize the auth service
            _authService = new AuthService();

            // create the logout command 
            LogoutCommand = new Command(OnLogoutClicked);

            BindingContext = this;

            // set the main page to the login view if not logged in
            CheckLoginStatus();

            //load theme
            ThemeService.LoadTheme();

            /*Preferences.Clear(); *///clear preferences for testing
        }

        private void CheckLoginStatus()
        {
            if (_authService.IsUserLoggedIn()) //if auth says user is logged in 
            {
                MainPage = new NavigationPage(new AppShell()); //take user to main page
            }
            else
            {
                MainPage = new NavigationPage(new LoginView()); //or stay on main page
            }
        }

        private void OnLogoutClicked()
        {
            _authService.Logout(); //if logout is clicked

            //back to login page
            Application.Current.MainPage = new LoginView();
        }
    }
}//comment to publish to github