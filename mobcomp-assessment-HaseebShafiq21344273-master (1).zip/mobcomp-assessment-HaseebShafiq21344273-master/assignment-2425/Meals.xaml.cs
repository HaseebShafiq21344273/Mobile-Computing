using System;
using System.Collections.ObjectModel;
using assignment_2425.Services;
using assignment_2425.View;
using System.Collections.Generic;

namespace assignment_2425
{
    // model classes for app usage, for each food item store these values
    public class FoodItem
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public string FoodId { get; set; }
        public string BrandName { get; set; }
        public double CaloriesPerServing { get; set; }
        public double ProteinPerServing { get; set; }
        public double CarbsPerServing { get; set; }
        public double FatPerServing { get; set; }
        public List<ServingSize> ServingSizes { get; set; } = new List<ServingSize>(); //serving sizes availabe for each food type
    }

    public class ServingSize //serving size option for each food
    {
        public string Description { get; set; }
        public double Quantity { get; set; }
        public string Unit { get; set; }
        public double Weight { get; set; }

        public override string ToString()
        {
            return Description; //display discription 
        }
    }

    // model for food diary entries
    public class FoodDiaryEntry
    {
        public string FoodId { get; set; }
        public string FoodName { get; set; }
        public string MealType { get; set; }
        public string ServingInfo { get; set; }
        public double Quantity { get; set; }
        public string ServingSizeUnit { get; set; }
        public double Calories { get; set; }
        public double Protein { get; set; }
        public double Carbs { get; set; }
        public double Fat { get; set; }
        public DateTime Date { get; set; }
    }

    public partial class Meals : ContentPage
    {
        private readonly INutritionixApiService _nutritionixService;  //access nutrionalx api database
        private FoodItem _selectedFood;                                 //for currently selected food item
        private ObservableCollection<FoodItem> _searchResults = new ObservableCollection<FoodItem>();               //collection of food results from search
        private ObservableCollection<FoodDiaryEntry> _foodDiary = new ObservableCollection<FoodDiaryEntry>();      //collection of food diary entries
        private MealsViewModel _view;           //view model for page

        // group the food diary by meal type, breakfast,lunch ect
        private ObservableCollection<Grouping<string, FoodDiaryEntry>> _groupedFoodDiary =
            new ObservableCollection<Grouping<string, FoodDiaryEntry>>();

        public Command<FoodDiaryEntry> DeleteFoodCommand { get; private set; } //command to delete food from diary

        public Meals()
        {
            InitializeComponent();

            _view = new MealsViewModel(new NutritionixApiService()); //create, use viewmdoel for this page
            BindingContext = _view; //set binding context
        }
    }

    // helper class for grouping in the collectionview
    public class Grouping<K, T> : ObservableCollection<T> //grouping function for food diary, group via meal type
    {
        public K Key { get; private set; }

        public Grouping(K key, IEnumerable<T> items)
        {
            Key = key;
            foreach (var item in items)
                this.Add(item);
        }
    }
} //comment to publish to github