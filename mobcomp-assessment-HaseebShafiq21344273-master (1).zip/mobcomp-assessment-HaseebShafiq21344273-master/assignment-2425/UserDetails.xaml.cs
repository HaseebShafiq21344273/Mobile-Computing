using System.Threading.Tasks;
using assignment_2425.Services;
namespace assignment_2425;

public partial class UserDetails : ContentPage
{
	public UserDetails()
	{
		InitializeComponent();

        if (_TrueMale)
        {
            MaleBorder.BackgroundColor = Colors.LightGreen; //change color depending on if male or female is tapped
            FemaleBorder.BackgroundColor = Colors.White;
        }
        else
        {
            FemaleBorder.BackgroundColor = Colors.LightGreen;
            MaleBorder.BackgroundColor = Colors.White;
        }
    }
	

    private async void CalculateIntake_Pressed(object sender, EventArgs e) //handler for calc button
    {
        HapticFeedback.Default.Perform(HapticFeedbackType.Click);// haptic feature

        int age = (int)ageselect.Value; //using users inputs
		double height = heightselect.Value;
		double weight = weightselect.Value;
        

    double activityLvl;                 //changed multiplier based on users checked option
		if (LowActivityRadio.IsChecked)
			activityLvl = 1.2;
		else if (MediumActivityRadio.IsChecked)
			activityLvl = 1.55;
		else
			activityLvl = 1.9;

			double calIntakeCalc;
		if (_TrueMale)
		{
			calIntakeCalc = 66 + (13.7 * weight) + (5 * height) - (6.8 * age); //formula based on male 
		}

		else
		{
            calIntakeCalc = 665 + (9.6 * weight) + (1.8 * height) - (4.7 * age); //formula based on female
		}

		double CalIntake = calIntakeCalc * activityLvl;  //use activitly level to determine final cal output
        int roundCalories = (int)Math.Round(CalIntake);  //round this number 

        Preferences.Set("RecommendedCalories", roundCalories); //save calories to use on mainpage

        await DisplayAlert("Daily Calorie Needs",
        $"Your estimated daily calorie intake is {roundCalories} calories.", //alert for user
        "OK");

        Vibration.Default.Vibrate(200); //vibration feature

    }
	private bool _TrueMale = true; //to see the selected gender
    private void MaleBorder_Tapped(object sender, EventArgs e)
    {
        HapticFeedback.Default.Perform(HapticFeedbackType.Click); //haptic feature
        _TrueMale = true;

        MaleBorder.BackgroundColor = Colors.LightGreen; 
        FemaleBorder.BackgroundColor = Colors.White;
    }

    private void FemaleBorder_Tapped(object sender, EventArgs e)
    {
        HapticFeedback.Default.Perform(HapticFeedbackType.Click); //haptic feedback
        _TrueMale = false;
        FemaleBorder.BackgroundColor = Colors.LightGreen; 
        MaleBorder.BackgroundColor = Colors.White;
    }
    private async void ReadUserContent_Clicked(object sender, EventArgs e)
    {
        // collect content from my page
        string UserContent = "UserDetails page. ";

        // add any available info from buttons
        if (MaleBorder.BackgroundColor == Colors.LightGreen)
        {
            UserContent += "Gender: Male. ";


        }
        else if (FemaleBorder.BackgroundColor == Colors.LightGreen)  //if user selected female , read female, vice versa
        {
            UserContent += "Gneder: Female";
        }

        UserContent += $"Age: {(int)ageselect.Value} years";
        UserContent += $"Height: {(int)heightselect.Value} centimeters";  //read selected values chosen by user
        UserContent += $"Weight: {(int)weightselect.Value} kilograms";

        // selected activity info added
        if (LowActivityRadio.IsChecked)
        {
            UserContent += "Actvity levlel is set to low";
        }
        else if (MediumActivityRadio.IsChecked)
        {
            UserContent += "Activity level is set to Medium";
        }
        else if (HighActivityRadio.IsChecked)
        {
            UserContent += "Activity level is set to High";
        }

        await TextToSpeechVoice.SpeakTextAsync(UserContent);
    }
            private void LowActivityRadio_CheckedChanged(object sender, CheckedChangedEventArgs e)
            {
                HapticFeedback.Default.Perform(HapticFeedbackType.Click); //haptic feedback
            }

    private void MediumActivityRadio_CheckedChanged(object sender, CheckedChangedEventArgs e)
    {
        HapticFeedback.Default.Perform(HapticFeedbackType.Click); //haptic feedback
    }

    private void HighActivityRadio_CheckedChanged(object sender, CheckedChangedEventArgs e)
    {
        HapticFeedback.Default.Perform(HapticFeedbackType.Click); //haptic feedback
    }
} //comment to publish to github