﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment_2425.Services
{
    public static class ThemeService
    {
        private const string ThemePreferenceKey = "AppTheme";

        public static void SetTheme(bool isDarkMode)
        {
            // save theme
            Preferences.Default.Set(ThemePreferenceKey, isDarkMode);

            // Set theme
            Application.Current.UserAppTheme = isDarkMode ? AppTheme.Dark : AppTheme.Light;
        }

        public static bool IsDarkMode()
        {
            // get saved theme
            return Preferences.Default.Get(ThemePreferenceKey, false);
        }

        public static void LoadTheme()
        {
            // when app starts, load theme
            bool isDarkMode = IsDarkMode();
            Application.Current.UserAppTheme = isDarkMode ? AppTheme.Dark : AppTheme.Light;
        }
    }
} //comment to publish to github
