namespace assignment_2425.Services
{
    public interface IAuthService
    {
        bool ValidateCredentials(string email, string password);
        void SaveUserSession(string email);
        bool IsUserLoggedIn();
        void Logout();
    }

    public class AuthService : IAuthService
    {
        // use preferences to store login state
        private const string UserEmailKey = "UserEmail";
        private const string IsLoggedInKey = "IsLoggedIn";

        public bool ValidateCredentials(string email, string password)
        {
            // simple validation
            // Example test account
            if (email == "test@example.com" && password == "password")
            {
                return true;
            }

            // ccept any email with a password longer than 5 chars
            return email.Contains("@") && email.Contains(".") && password.Length > 5;
        }

        public void SaveUserSession(string email) //save teh users login session 
        {
            Preferences.Set(UserEmailKey, email);
            Preferences.Set(IsLoggedInKey, true);
        }

        public bool IsUserLoggedIn()
        {
            return Preferences.Get(IsLoggedInKey, false); //check method to see if user is logged in 
        }

        public void Logout()
        {
            Preferences.Remove(UserEmailKey);  //method for when user logs out remove email
            Preferences.Set(IsLoggedInKey, false); //set to false
        }
    }
}

//comment to publish to github