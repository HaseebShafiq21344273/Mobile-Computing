﻿using assignment_2425.Services;
using assignment_2425.ViewModels;
using System.Text.Json;

namespace assignment_2425
{
    public partial class MainPage : ContentPage
    {
        private readonly MainPageViewModel _viewModel; //reference for viewmodel

        public MainPage()
        {
            InitializeComponent();
            _viewModel = new MainPageViewModel(new AuthService()); //create mainpageviewmodel with authservice
            BindingContext = _viewModel; // binding to connect to ui
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();
            _viewModel.LoadFoodDiaryData(); //load food data when we enter page
            _viewModel.LoadRecommendedCalories(); //load users recommended cal intake
        }
        public class FoodDiaryEntry // food dairy entry for nutritional values
        {
            public double Calories { get; set; }
            public double Protein { get; set; }
            public double Carbs { get; set; }
            public double Fat { get; set; }
        }


        private void ReadMainContent_Clicked(object sender, EventArgs e) //e handeler for read content button
        {
            ((Command)_viewModel.ReadMainContentCommand).Execute(null); //execute command to read page content
        }
    }
}//comment to publish to github