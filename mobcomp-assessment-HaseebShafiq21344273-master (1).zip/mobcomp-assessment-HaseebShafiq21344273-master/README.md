# Mobile Computing Assessment 24/25

Use this README to:
- Briefly describe your app
- Keep track of features that you want to implement/have implemented
- Any useful information that may help when marking

You can modify this file and the starter project as you see fit.

You must **NOT** delete or modify the following files unless instructed by your tutor:
- .gitignore
- .gitattributes

Creating a calorie tracker application

Current Fetaures Implemnted: 
Login Page
auth for login page
error handling for login page
Initial mainpage , button, clean nav

features to implement
binding for nav
calorie counting 
other content pages

--------------------------

I Have missed many commits as I kept storing them locally rather than pushin - whoops

- updated nav bar - home,meals,sats(might remove), profile

- updated flyout tab

- created your details section for user to input weight, male/female/ height/ actlvl - gives user daily calorie intake for maintenance.
--------------------------

- Api integration

- using nutritionx api service to receive food info

- creating xaml page for Meals

- layout for xaml meals compelted, search entry for user, food info for portion sizing, portion options, nutrion info calculated based on serving size. 

- food diary output for, Breakfast, lunch, dinner and snacks section

- researching api integration

- tested Get method - multiple errors

-  trying different methods - multiple errors - struggling to pull info and display

- resource dictionary integration for fonts and colours- light and dark mode

- tested android tablet layout, - works with no errors
----------------------------
to do - mainpage format - daily calorie intake pie chart

- create other xaml pages for profile section and flyout tab bar
- create contact us xaml and cs

----------------------------
What i did in my Commits that didnt go through

- Mvvm model for both meals page and main page, to notify ui and update macro information for user
- fixed delete button issue, now working
- seperated api service into services class
- light/ dark mode - fixed issues with background
- tried inplementing app styes and colors, but styles became an issue as each page varied in content
- text to speech, seperated and made into a service class so any page can use it without setting it for each page
- added more vibration to any errors i missed out
- code cleaning
- commenting all code
- contact us page created and implemented with app function txt to speech
- api error wouldnt pul info after app was running for a long period of time
- app testing in general, check to se if the app break the run time
- final touches
- main page mvvm model, seperated for code clenliness
- implementation of mainpage feature - updating macro breakdown and cal count with recommended cal intake
- text to speech buttons supported image for light/dark mode

- many hours of work, i hope u like the app ;)


