namespace assignment_2425;

public partial class profilepage : ContentPage
{
	public profilepage()
	{
		InitializeComponent();
	}
    private async void OnDetailsClicked(object sender, EventArgs e)
    {
        //  haptic feedback
        HapticFeedback.Default.Perform(HapticFeedbackType.Click);

        // navigate to details page
        await Navigation.PushAsync(new UserDetails());
    }

    private async void OnSettingsClicked(object sender, EventArgs e)
    {
        // haptic feedback
        HapticFeedback.Default.Perform(HapticFeedbackType.Click);

        // navigate to settings page
        await Navigation.PushAsync(new Settings());
    }
} //comment to publish to github